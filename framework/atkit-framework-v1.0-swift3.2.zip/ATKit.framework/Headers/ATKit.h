//
//  ATKit.h
//  ATKit
//
//  Created by Rupendra on 11/01/18.
//  Copyright © 2018 Aurvan.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ATKit.
FOUNDATION_EXPORT double ATKitVersionNumber;

//! Project version string for ATKit.
FOUNDATION_EXPORT const unsigned char ATKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ATKit/PublicHeader.h>


